# -*- coding: utf-8 -*-
"""Top-level package for Plone CLI."""

import pkg_resources


__author__ = """Maik Derstappen"""
__email__ = "md@derico.de"
__version__ = pkg_resources.require("plonecli")[0].version
